import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ClientMain {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		Socket socket = new Socket("192.168.168.124", 800);
		System.out.printf("Connected to %s\n", socket.getInetAddress());
		
		DataInputStream dis = new DataInputStream(socket.getInputStream());
		DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
		
		Scanner scanner = new Scanner(System.in);
		String input = "";
		String output = "";
		
		while (!output.equals("End")) {
			output = scanner.next();
			dos.writeUTF(output);
			dos.flush();
			
			input = dis.readUTF().toString();
			System.out.printf("Server says: %s\n", input);
		}
		
		scanner.close();
		socket.close();
	}

}
