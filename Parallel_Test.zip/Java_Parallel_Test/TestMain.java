import java.io.IOException;
import java.util.concurrent.*;
import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		long[] array = new long[1000000000];
		Scanner scanner = new Scanner(System.in);
		
		for (int i = 0; i < array.length; i++) {
			array[i] = i;
		}
		
		long startTime = System.nanoTime();
		
		System.out.println("Enter 1 to test Non-Parallel Computing, 2 to test Parallel Computing, 3 to test FetchContent");
		switch (scanner.next()) {
		case ("1"):
			//Non-Parallel
			for (int i = 0; i < 20; i++) {
				long normalResult = 0;
				for (int n = 0; n < array.length; n++) {
					normalResult += array[n]*array[n];
				}
				System.out.println(normalResult);
			}
			break;
		case ("2"):
			//Parallel (Using Fork)
			for (int i = 0; i < 20; i++) {
				ForkJoinPool pool = new ForkJoinPool();
				long parallelResult = pool.invoke(new Calculation(array, 0, array.length));
				System.out.println(parallelResult);
			}
			break;
		case("3"):
			FetchContent fetcher = new FetchContent("computer", 10);
		
			for (String result: fetcher.fetchContent()) {
				System.out.println(result);
			}
			break;
		}

		long endTime = System.nanoTime();
		System.out.println(endTime - startTime);
	}
	//8158227399
	//8213803000
	//8323146901
	//8214488000
	//8044066901
	
	//2086530900
	//2065852601
	//2108037000
	//2082358400
	//2039398300
	
	//Ans: 3338615082255021824
}
