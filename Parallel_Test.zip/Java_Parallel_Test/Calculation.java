import java.util.concurrent.*;

public class Calculation extends RecursiveTask<Long>{
	private long[] array;
	private int start;
	private int end;
	
	public Calculation(long[] array, int start, int end) {
		this.array = array;
		this.start = start;
		this.end = end;
	}

	@Override
	protected Long compute() {
		// TODO Auto-generated method stub
		if (end - start <= 100000) {
			long sum = 0;
			
			for (int i = start; i < end; i++) {
				sum += array[i]*array[i];
			}
			
			return sum;
		} else {
			int mid = (start + end) / 2;
			Calculation left = new Calculation(array, start, mid);
			Calculation right = new Calculation(array, mid, end);
			left.fork();
			right.fork();
			return right.join() + left.join();
		}
	}
}
