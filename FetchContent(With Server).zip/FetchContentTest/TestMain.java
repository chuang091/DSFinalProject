import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class TestMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		InetAddress localhost = InetAddress.getLocalHost();
		
		ServerSocket serverSocket = new ServerSocket(800);
		System.out.println("Server Started");
		System.out.printf("Please connect client to %s\n", localhost);
		
		Socket clientSocket = serverSocket.accept();
		System.out.println("Client Connected");
		
		DataInputStream dis = new DataInputStream(clientSocket.getInputStream());
		DataOutputStream dos = new DataOutputStream(clientSocket.getOutputStream());
		
		Scanner scanner = new Scanner(System.in);
		String input = dis.readUTF();
		String output = "";
		System.out.printf("Client says: %s\n", input);
		
		FetchContent fetcher = new FetchContent(input, 10);
		
		try {
			for (String result: fetcher.fetchContent()) {
				output += String.format("%s\n", result);
			}
			
			dos.writeUTF(output);
			dos.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		scanner.close();
		serverSocket.close();
	}

}
