import java.util.ArrayList;

public class Sequence{
	ArrayList<Integer> list;
	ArrayList<Integer> workingList;
	
	public Sequence() {
		list = new ArrayList<Integer>();
		
		createList();
		
		workingList = list;
	}
	
	private void createList() {
		for (int i = 0; i < 50000000; i++) {
			list.add((int) Math.floor(Math.random()*50000000));
		}
	}
	
	public ArrayList<Integer> getList() {
		return workingList;
	}
	
	public void singleThreadQuickSort() {
		quickSort(0, workingList.size() - 1);
		//output();
	}
	
	private void quickSort(int leftbound, int rightbound)
	{
		if (leftbound >= rightbound) {return;}
		
		int pivot = rightbound;
		int smaller = leftbound;
		int larger = rightbound - 1;
		
		while (smaller < larger) {
			while (!(workingList.get(smaller) > workingList.get(pivot) || smaller >= larger)) {
				smaller++;
			}
			while (!(workingList.get(larger) <= workingList.get(pivot) || larger <= smaller)) {
				larger--;
			}
			
			if (smaller < larger) {
				swap(smaller, larger);
			}
		}
		
		//output();
		//System.out.println(workingList.get(pivot));
		//System.out.println(smaller);
		
		if (!((smaller == pivot - 1) && (workingList.get(smaller) < workingList.get(pivot)))) {
			swap(smaller, pivot);
			
			pivot = smaller;
		}
		
		quickSort(leftbound, pivot - 1);
		quickSort(pivot + 1, rightbound);
	}

	private void swap(int aIndex, int bIndex)
	{
		int temp = workingList.get(aIndex);
		workingList.set(aIndex, workingList.get(bIndex));
		workingList.set(bIndex, temp);
	}
	
	public void output() {
		for (int i: workingList) {
			System.out.print(String.format("[%d]", i));
		}
		System.out.println();
	}
}
