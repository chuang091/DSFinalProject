import java.util.ArrayList;
import java.util.concurrent.RecursiveTask;
import java.lang.IllegalArgumentException;

public class ExtendedSequence extends RecursiveTask<ArrayList<Integer>>{
	private static final long serialVersionUID = 1L;
	
	ArrayList<Integer> workingList;
	
	public ExtendedSequence(ArrayList<Integer> list) {
		this.workingList = list;
	}
	
	public ArrayList<Integer> getList() {
		return workingList;
	}

	@Override
	protected ArrayList<Integer> compute() {
		quickSort(0, workingList.size() - 1);
		//output();
		return workingList;
	}
	
	private void quickSort(int leftbound, int rightbound)
	{
		if (leftbound >= rightbound) {return;}
		
		int pivotValue = workingList.get(rightbound);
		int pivot = rightbound;
		int smaller = leftbound;
		int larger = rightbound - 1;
		
		while (smaller < larger) {
			while (!(workingList.get(smaller) > workingList.get(pivot) || smaller >= larger)) {
				smaller++;
			}
			while (!(workingList.get(larger) <= workingList.get(pivot) || larger <= smaller)) {
				larger--;
			}
			
			if (smaller < larger) {
				swap(smaller, larger);
			}
		}
		
		//output();
		//System.out.println(workingList.get(pivot));
		//System.out.println(smaller);
		
		if (!((smaller == pivot - 1) && (workingList.get(smaller) < workingList.get(pivot)))) {
			swap(smaller, pivot);
			pivot = smaller;
		}
		
		if (workingList.size() < 5000000) {
			quickSort(leftbound, pivot - 1);
			quickSort(pivot + 1, rightbound);
		} else {
			try {
				ExtendedSequence left = new ExtendedSequence(new ArrayList<Integer>(workingList.subList(leftbound, pivot)));
				ExtendedSequence right = new ExtendedSequence(new ArrayList<Integer>(workingList.subList(pivot + 1, rightbound + 1)));

				left.fork();
				right.fork();
				
				ArrayList<Integer> temp = new ArrayList<Integer>();
				temp.addAll(left.join());
				temp.add(pivotValue);
				temp.addAll(right.join());
				workingList.clear();
				workingList.addAll(temp);
				/*for (int i: temp) {
					System.out.printf("[%d]", i);
				}
				System.out.println();*/
			} catch (IllegalArgumentException e) {
				
			}
		}
		
	}

	private void swap(int aIndex, int bIndex)
	{
		int temp = workingList.get(aIndex);
		workingList.set(aIndex, workingList.get(bIndex));
		workingList.set(bIndex, temp);
	}
	
	public void output() {
		for (int i: workingList) {
			System.out.print(String.format("[%d]", i));
		}
		System.out.println();
	}
}
