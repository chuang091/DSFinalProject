import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sequence sequence = new Sequence();
		//ExtendedSequence xsequence = new ExtendedSequence(sequence.getList());
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter 1 for single thread, 2 for multithread");
		
		long start = System.currentTimeMillis();
		switch(scanner.nextInt()) {
		case(1):
			sequence.singleThreadQuickSort();
			break;
		case(2):
			ForkJoinPool pool = new ForkJoinPool();
			ArrayList<Integer> list = pool.invoke(new ExtendedSequence(sequence.getList()));
			
			/*for (int i: list) {
				System.out.print(String.format("[%d]", i));
			}
			System.out.println();*/
			
			int max = 0;
			
			for (int i: list) {
				if (i < max) {
					System.out.printf("fucked at [%d]\n", i);
				}
				max = i;
			}
			
			break;
		}
		long end = System.currentTimeMillis();
		scanner.close();
		System.out.println((end - start));

	}
	
	//11807754500
	//11601414200
	//11669902700
	//5987062600
	//6449453000
	//6322750700
}
