import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class Algorithm {
	//WARNING: Using MultiThread would use 100% of your CPU for a short amount of time
	//Your device may become laggy or even frozen - Depends on your device
	//And even after results shows, the threads may not have terminated
	//Please use it carefully
	int process = 1;//多執行緒(目前可以手動切換)
	KeywordList horrorList, scifiList;
	String query;
	
	public Algorithm() {
		horrorList = new KeywordList();
        horrorList.add(new Keyword("恐怖", 5.0f));
        horrorList.add(new Keyword("毛骨悚然", 5.0f));
        horrorList.add(new Keyword("神鬼", 5.0f));
        horrorList.add(new Keyword("驚悚", 4.5f));
        horrorList.add(new Keyword("靈異", 4.5f));
        horrorList.add(new Keyword("詭異", 4.0f));
        horrorList.add(new Keyword("血腥", 4.0f));
        horrorList.add(new Keyword("咒怨", 4.0f));
        horrorList.add(new Keyword("鬼屋", 3.5f));
        horrorList.add(new Keyword("暗黑", 3.5f));
        horrorList.add(new Keyword("屍體", 3.0f));
        horrorList.add(new Keyword("詭秘", 2.0f));
        
        scifiList = new KeywordList();
        scifiList.add(new Keyword("科幻", 5.0f));
        scifiList.add(new Keyword("超能力", 5.0f));
        scifiList.add(new Keyword("未來", 5.0f));
        scifiList.add(new Keyword("太空", 4.5f));
        scifiList.add(new Keyword("外星", 4.5f));
        scifiList.add(new Keyword("機器人", 4.0f));
        scifiList.add(new Keyword("時空", 4.0f));
        scifiList.add(new Keyword("星際", 4.0f));
        scifiList.add(new Keyword("末日", 3.5f));
        scifiList.add(new Keyword("人工智能", 3.5f));
        scifiList.add(new Keyword("穿越", 3.0f));
        scifiList.add(new Keyword("幻想", 2.0f));
        
        query = "";
	}
	
	public String getResult(String query) throws IOException {
		this.query = query;
		
		String result = "";
		String genre = query.split(" ")[query.split(" ").length - 1];
		switch (genre) {
		case ("恐怖片"):
			result = start(horrorList);
			break;
		case ("科幻片"):
			result = start(scifiList);
			break;
		}
		
		return result;
	}
	
	public String start(KeywordList genreList) throws IOException {
		//取得標題和URL，計算分數
        long start = System.currentTimeMillis();
        HashMap<String, String> titleAndURL = new GoogleQuery(query).query();
        ArrayList<WebTree> webTrees = new ArrayList<WebTree>();
        
        int[] progress = new int[1];
        
        
        for (Map.Entry<String, String> entry : titleAndURL.entrySet()) {
        	
        	if (process == 0) {
        		String title = entry.getKey();
                String url = entry.getValue();
                
                try {
                	 WebPage webPage = new WebPage(url, title);
		             WebTree webTree = new WebTree(webPage);

		             // 網頁的分數
		             webTree.setNodeScore(genreList.getList());//
		             webTrees.add(webTree);
                } catch (IOException e) {
                    // URL 找不到的情況
                    //System.out.println("Some URL is Messed up");
                }
                
                progress[0] += 1;
                System.out.println(String.format("Progress: %d", Math.round(progress[0]/(double) titleAndURL.size() * 100)) + "%");
        	} else {
        		class Job implements Runnable {
        			int[] progress;
        			
        			@SuppressWarnings("unused")
					public Job() {
        				
        			}
        			
        			public Job(int progress[]) {
        				this.progress = progress;
        			}

					@Override
					public void run() {
						synchronized(this) {
							method(progress);
						}
					}
					
					private void method(int[] progress) {
						String title = entry.getKey();
    		            String url = entry.getValue();

    		            try {
    		                WebPage webPage = new WebPage(url, title);
    		                WebTree webTree = new WebTree(webPage);

    		                // 網頁的分數
    		                webTree.setNodeScore(genreList.getList());//
    		                webTrees.add(webTree);
    		            } catch (IOException e) {
    		                // URL 找不到的情況
    		                
    		            }
    		            
    		            progress[0] += 1;
    		            System.out.println(String.format("Progress: %d", Math.round(progress[0]/(double) titleAndURL.size() * 100)) + "%");
					}
        		}
        		
        		Thread thread = new Thread(new Job(progress));
            	
            	thread.start();
        	}
        }
        
        while (progress[0] < titleAndURL.entrySet().size()) {
        	try {
        		TimeUnit.MILLISECONDS.sleep(100);
        	} catch (InterruptedException e) {
        		e.printStackTrace();
        	}
        }
        
        System.out.print("Total Pages: ");
        System.out.println(webTrees.size());
        
        // 使用快速排序將 webPages 由分數高到低排序
        WebPageSorter.quickSort(webTrees);
       
            
        
        String result = "";
       //印出結果
        for (WebTree webTree : webTrees) {
            System.out.println("Title：" + webTree.getRoot().getWebPage().getName());
            System.out.println("URL：" + webTree.getRoot().getWebPage().getUrl());
            System.out.println("Points：" + webTree.getTreeScore());

            

            System.out.println("-------------------------------------------------------");
            
            result += String.format("%s, %s, %s\n", webTree.getRoot().getWebPage().getName(), webTree.getRoot().getWebPage().getUrl(), webTree.getRoot().getWebPage().getScore());
        }
        
        long end = System.currentTimeMillis();
        
        System.out.println(String.format("Total Time Taken: %.2f seconds", (end - start) / 1000f));
        
        return result;
	}
}
