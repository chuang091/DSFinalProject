import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WordCounter {
	private String url;
	private String content;
	private volatile ArrayList<WebNode> children;
	
	volatile int[] count = new int[1];
	volatile int[] i = {0};
	
	public WordCounter(String url) throws IOException {
		try {
			if (!(url.contains("http://") || url.contains("https://"))) {
				url = "https://" + url;
			}
			
			this.url = URLDecoder.decode(url, "utf-8");
			this.content = fetchContent();
		} catch (UnsupportedEncodingException e) {
			System.out.println("Unsupported URL");
		}
		
	}
	
	public ArrayList<WebNode> getChildren(WebNode parent) {
		HashMap<String, String> resultList = new HashMap<String, String>();
		children = new ArrayList<WebNode>();
		
		Document doc = Jsoup.parse(content);
		
		Elements lis = doc.select("a");
		
		for (Element li: lis) {
			String url = li.attr("href").replace("/url?q=", "");
			String title = li.select(".vvjwJb").text();
			
			if (title == null || title == "") {
				title = "Test" + lis.indexOf(li);
			}
			
			resultList.put(title, url);
		}
		
		Thread thread = new Thread(new Runnable() {
			@Override
			public void run() {
				synchronized(this) {
					for (Map.Entry<String, String> entry: resultList.entrySet()) {
						Thread thread = new Thread(new Runnable() {
							@Override
							public void run() {
								synchronized(this) {
									try {
										WebPage webPage = new WebPage(entry.getValue(), entry.getKey());
										WebNode child = new WebNode(webPage, parent);
										children.add(child);
									} catch (IOException e1) {
										System.out.print("");
									} catch (IllegalArgumentException e2) {
										System.out.print("");
									} catch (ClassCastException e3) {
										System.out.print("");
									} catch (Exception e4) {
										System.out.print("");
									}
									i[0]--;
									
									count[0] ++;
								}
							}
						});
						thread.start();
						i[0]++;
					}
					
					while (count[0] < ((double)resultList.size() * 0.95)) {
						try {
							TimeUnit.MILLISECONDS.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}
		});
		thread.start();
		
		while (i[0] > 0) {
			try {
				TimeUnit.MILLISECONDS.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		return children;
	}
	
	public int countKeyword(String keyword) throws IOException {
		content = content.toUpperCase();
		keyword = keyword.toUpperCase();
		
		int result = 0, startIndex = 0, found = -1;
		
		while ((found = content.indexOf(keyword, startIndex)) != -1) {
			result ++;
			startIndex = found + keyword.length();
		}
		
		return result;
	}
	
	private String fetchContent() throws IOException, ClassCastException {
		HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
		conn.setConnectTimeout(1000);
		conn.setReadTimeout(2000);
		conn.setRequestProperty("User-agent", "Chrome/107.0.5304.107");
		InputStream is = conn.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(is, "utf-8"));
		
		String result = "", line = null;
		while ((line = br.readLine()) != null) {
			result += (String.format("%s\n", line));
		}
		
		return result;
	}
}
